import abc
from .common import ClassParameter as ClassParameter
from .exceptions import HeuristicException as HeuristicException, ParameterException as ParameterException, ParameterValueException as ParameterValueException
from _typeshed import Incomplete
from typing import Any

class Problem(abc.ABC, metaclass=abc.ABCMeta):
    """Base class for defining search problems.

    A problem is modelled with the same five operations used to define a
    search problem in theory. Any state must be hashable and comparable, and
    any action can be an arbitrary hashable value (see `format_action`).

    - `initials()`: the list of initial states.
    - `actions(s)`: the list of actions that are valid in state ``s``.
    - `result(s, a)`: the state obtained by applying action ``a`` to ``s``.
    - `cost(s, a)`: the cost of applying action ``a`` to ``s``.
    - `is_goal(s)`: whether ``s`` is a goal state.

    The methods `result` and `cost` can assume that ``a`` is one of the
    actions returned by ``actions(s)``. `result` must **not** modify ``s``.

    It also provides utilities for heuristics and visualization.

    Attributes:
        PARAMS (list[ClassParameter]): List of configurable class parameters.
    """
    PARAMS: list[ClassParameter]
    def __init_subclass__(cls, **kwargs) -> None: ...
    @classmethod
    def get_name(cls) -> str:
        """Get the problem's name.

        Returns:
            str: The name of the problem, either from the class attribute
            ``NAME`` (if defined) or the class name itself.
        """
    @classmethod
    def heuristic(cls, h_cls):
        """Register a heuristic for this problem.

        Should be used as a decorator for a sublclass of `Heuristic`.

        Args:
            h_cls (type): The heuristic class to register.

        Returns:
            type: The registered heuristic class (unchanged).
        """
    @classmethod
    def visualizer(cls):
        """Get the visualizer associated with this problem.

        Returns:
            SolutionVisualizer | None: The visualizer object if defined
            in the class attribute ``VISUALIZER``, otherwise ``None``.
        """
    @property
    def name(self) -> str:
        """str: The name of the problem instance."""
    @abc.abstractmethod
    def initials(self) -> list[Any]:
        """Return the initial states of the problem.

        Returns:
            list[Any]: A list with all the initial states.
        """
    @abc.abstractmethod
    def actions(self, s) -> list[Any]:
        '''Return the actions that can be applied in a state.

        Only valid actions must be returned.

        Args:
            s (Any): The state.

        Returns:
            list[Any]: The valid actions in ``s``. An action can be any
            hashable value, a tuple such as ``("move", 0, 2)`` is recommended
            when the action has parameters.
        '''
    @abc.abstractmethod
    def result(self, s, a) -> Any:
        """Return the state resulting from applying an action to a state.

        The action is assumed to be valid in ``s``. The state ``s`` must not
        be modified, return a new state instead.

        Args:
            s (Any): The state.
            a (Any): One of the actions returned by ``actions(s)``.

        Returns:
            Any: The resulting state.
        """
    @abc.abstractmethod
    def cost(self, s, a) -> float:
        """Return the cost of applying an action to a state.

        The action is assumed to be valid in ``s``.

        Args:
            s (Any): The state.
            a (Any): One of the actions returned by ``actions(s)``.

        Returns:
            float: The cost of the action.
        """
    @abc.abstractmethod
    def is_goal(self, s) -> bool:
        """Check if a state is a goal state.

        Args:
            s (Any): The state to check.

        Returns:
            bool: ``True`` if the state is a goal state, ``False`` otherwise.
        """

def format_action(a) -> str:
    '''Return a readable label for an action.

    A tuple whose first element is a string is shown as a call, e.g.
    ``("pour", 0, 1)`` becomes ``pour(0, 1)``. Any other action is
    converted with ``str``.

    Args:
        a (Any): The action.

    Returns:
        str: The label of the action.
    '''

class CountingProblem:
    """Wrapper of a `Problem` that counts the number of expanded states.

    A state is considered expanded each time `actions` is called on it.
    Any other attribute is delegated to the wrapped problem.
    """
    def __init__(self, problem) -> None: ...
    @property
    def problem(self):
        """Problem: The wrapped problem."""
    @property
    def num_expanded(self) -> int:
        """int: Number of states expanded so far."""
    def initials(self): ...
    def actions(self, s): ...
    def result(self, s, a): ...
    def cost(self, s, a): ...
    def is_goal(self, s): ...
    def __getattr__(self, name): ...

class Heuristic(metaclass=abc.ABCMeta):
    """Abstract base class for heuristics.

    A `Heuristic` represents a function that assigns an estimated value
    to a given state of a problem. Subclasses must implement the
    :meth:`compute` method to define the heuristic evaluation.

    Attributes:
        problem (Problem): The problem instance for which the heuristic is defined.
    """
    @classmethod
    def get_name(cls):
        """Get the name of the heuristic class.

        If the subclass defines a ``NAME`` attribute, it will be used.
        Otherwise, the class name is returned.

        Returns:
            str: The name of the heuristic.
        """
    problem: Incomplete
    def __init__(self, problem: Problem) -> None:
        """Initialize the heuristic with a problem instance.

        Args:
            problem (Problem): The problem instance on which the heuristic operates.
        """
    @abc.abstractmethod
    def compute(self, state):
        """Compute the heuristic value for a given state.

        This method must be implemented by subclasses.

        Args:
            state: The state of the problem to evaluate.

        Returns:
            float | int: The heuristic value associated with the state.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
    def __call__(self, state): ...

class NullHeuristic(Heuristic):
    NAME: str
    def __init__(self) -> None: ...
    def compute(self, state): ...

def register_heuristic(p_cls, h_cls) -> None: ...
def has_heuristic(problem_cls, heuristic_name): ...
def get_heuristics(problem_cls): ...
def get_heuristic(problem_cls, heuristic_name): ...
